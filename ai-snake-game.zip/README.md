# AI Snake Game

Yapay zeka ile oynayan yılan oyunu.

## Çalıştırmak için:

```
pip install -r requirements.txt
python game.py
```